const $=id=>document.getElementById(id);
async function api(url,opt={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opt});const d=await r.json();if(!r.ok)throw Error(d.error||"Request failed");return d}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function loadMe(){const u=await api("/api/me");$("who").textContent=u?`Hi, ${u.name}`:"Not logged in"}
function openAuth(){$("auth").showModal()}
async function register(){try{await api("/api/register",{method:"POST",body:JSON.stringify({name:$("name").value,email:$("email").value,password:$("password").value,bio:$("bio").value})});$("auth").close();await loadMe();await loadFeed();alert("Registration successful")}catch(e){alert(e.message)}}
async function login(){try{await api("/api/login",{method:"POST",body:JSON.stringify({email:$("email").value,password:$("password").value})});$("auth").close();await loadMe();await loadFeed();alert("Login successful")}catch(e){alert(e.message)}}
async function logout(){await api("/api/logout",{method:"POST"});loadMe();loadFeed()}
async function createPost(){try{await api("/api/posts",{method:"POST",body:JSON.stringify({content:$("post").value})});$("post").value="";loadFeed()}catch(e){alert(e.message)}}
async function like(id){try{await api(`/api/posts/${id}/like`,{method:"POST"});loadFeed()}catch(e){alert(e.message)}}
async function comment(id){const content=prompt("Write a comment");if(!content)return;try{await api(`/api/posts/${id}/comments`,{method:"POST",body:JSON.stringify({content})});loadFeed()}catch(e){alert(e.message)}}
async function follow(id){try{await api(`/api/users/${id}/follow`,{method:"POST"});alert("Follow status updated")}catch(e){alert(e.message)}}
async function deletePost(id){if(confirm("Delete this post?")){try{await api(`/api/posts/${id}`,{method:"DELETE"});loadFeed()}catch(e){alert(e.message)}}}
async function loadFeed(){try{const posts=await api("/api/feed");$("feed").innerHTML=posts.length?posts.map(p=>`<article class="post"><b>${esc(p.name)}</b><div class="meta">${new Date(p.created_at).toLocaleString()}</div><p>${esc(p.content)}</p><div class="actions"><button class="${p.liked?"liked":""}" onclick="like(${p.id})">♥ ${p.likes}</button><button onclick="comment(${p.id})">💬 ${p.comments.length}</button><button onclick="follow(${p.user_id})">Follow</button>${p.user_id===(window.meId||-1)?`<button onclick="deletePost(${p.id})">Delete</button>`:""}</div><div>${p.comments.map(c=>`<div class="comment"><b>${esc(c.name)}</b>: ${esc(c.content)}</div>`).join("")}</div></article>`).join(""):"<p>No posts yet.</p>"}catch(e){}}
async function init(){const u=await api("/api/me");window.meId=u?.id||-1;$("who").textContent=u?`Hi, ${u.name}`:"Not logged in";loadFeed()}init();
