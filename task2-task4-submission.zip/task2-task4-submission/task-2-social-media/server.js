const express=require("express");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const path=require("path");
const app=express(),db=new Database("social.db");
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
app.use(session({secret:process.env.SESSION_SECRET||"change-me",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax"}}));
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,bio TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,content TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id INTEGER NOT NULL,content TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER NOT NULL,post_id INTEGER NOT NULL,PRIMARY KEY(user_id,post_id));
CREATE TABLE IF NOT EXISTS follows(follower_id INTEGER NOT NULL,following_id INTEGER NOT NULL,PRIMARY KEY(follower_id,following_id));
`);
const auth=(req,res,next)=>req.session.user?next():res.status(401).json({error:"Login required"});
app.post("/api/register",async(req,res)=>{
 const {name,email,password,bio=""}=req.body;
 if(!name||!email||!password)return res.status(400).json({error:"All fields are required"});
 try{const hash=await bcrypt.hash(password,10);const r=db.prepare("INSERT INTO users(name,email,password,bio) VALUES(?,?,?,?)").run(name,email,hash,bio);req.session.user={id:r.lastInsertRowid,name};res.json(req.session.user)}
 catch(e){res.status(400).json({error:"Email already registered"})}
});
app.post("/api/login",async(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE email=?").get(req.body.email);
 if(!u||!(await bcrypt.compare(req.body.password,u.password)))return res.status(401).json({error:"Invalid email or password"});
 req.session.user={id:u.id,name:u.name};res.json(req.session.user);
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json(req.session.user||null));
app.get("/api/users/:id",(req,res)=>{
 const u=db.prepare("SELECT id,name,bio FROM users WHERE id=?").get(req.params.id);
 if(!u)return res.status(404).json({error:"User not found"});
 u.followers=db.prepare("SELECT COUNT(*) c FROM follows WHERE following_id=?").get(u.id).c;
 u.following=db.prepare("SELECT COUNT(*) c FROM follows WHERE follower_id=?").get(u.id).c;
 res.json(u);
});
app.get("/api/feed",(req,res)=>{
 const me=req.session.user?.id||0;
 const posts=db.prepare(`SELECT p.id,p.content,p.created_at,u.id user_id,u.name,
 (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
 EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) liked
 FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC`).all(me);
 for(const p of posts)p.comments=db.prepare(`SELECT c.id,c.content,c.created_at,u.name FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id`).all(p.id);
 res.json(posts);
});
app.post("/api/posts",auth,(req,res)=>{
 if(!req.body.content?.trim())return res.status(400).json({error:"Post cannot be empty"});
 const r=db.prepare("INSERT INTO posts(user_id,content) VALUES(?,?)").run(req.session.user.id,req.body.content.trim());
 res.json({id:r.lastInsertRowid});
});
app.delete("/api/posts/:id",auth,(req,res)=>{
 const p=db.prepare("SELECT user_id FROM posts WHERE id=?").get(req.params.id);
 if(!p)return res.status(404).json({error:"Post not found"});
 if(p.user_id!==req.session.user.id)return res.status(403).json({error:"Not your post"});
 db.prepare("DELETE FROM comments WHERE post_id=?").run(req.params.id);
 db.prepare("DELETE FROM likes WHERE post_id=?").run(req.params.id);
 db.prepare("DELETE FROM posts WHERE id=?").run(req.params.id);
 res.json({ok:true});
});
app.post("/api/posts/:id/like",auth,(req,res)=>{
 const id=req.params.id,has=db.prepare("SELECT 1 FROM likes WHERE user_id=? AND post_id=?").get(req.session.user.id,id);
 has?db.prepare("DELETE FROM likes WHERE user_id=? AND post_id=?").run(req.session.user.id,id):db.prepare("INSERT INTO likes VALUES(?,?)").run(req.session.user.id,id);
 res.json({liked:!has});
});
app.post("/api/posts/:id/comments",auth,(req,res)=>{
 if(!req.body.content?.trim())return res.status(400).json({error:"Comment cannot be empty"});
 db.prepare("INSERT INTO comments(post_id,user_id,content) VALUES(?,?,?)").run(req.params.id,req.session.user.id,req.body.content.trim());
 res.json({ok:true});
});
app.post("/api/users/:id/follow",auth,(req,res)=>{
 const id=Number(req.params.id); if(id===req.session.user.id)return res.status(400).json({error:"Cannot follow yourself"});
 const has=db.prepare("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?").get(req.session.user.id,id);
 has?db.prepare("DELETE FROM follows WHERE follower_id=? AND following_id=?").run(req.session.user.id,id):db.prepare("INSERT INTO follows VALUES(?,?)").run(req.session.user.id,id);
 res.json({following:!has});
});
app.listen(3002,()=>console.log("Task 2 running at http://localhost:3002"));
