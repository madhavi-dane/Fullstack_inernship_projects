# Task 2 – Social Media Platform

A mini social-media platform built with Express, SQLite, sessions, bcrypt, HTML, CSS and vanilla JavaScript.

## Features
- Registration/login/logout
- User profiles API
- Create/delete posts
- Comments
- Likes
- Follow/unfollow
- SQLite persistence

## Run
```bash
npm install
npm start
```
Open `http://localhost:3002`.

## GitHub evidence
Take screenshots of registration, feed, comments/likes and database/API behavior for your internship documentation.
