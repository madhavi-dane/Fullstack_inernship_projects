# Internship Tasks 2 & 4

These are replacement projects for an internship where Task 1 and Task 3 are already complete.

## Task 2
Social Media Platform — Express + SQLite + sessions + bcrypt + vanilla JS.

## Task 4
Real-Time Communication — WebRTC + Socket.IO + vanilla JS.

## Add to an existing GitHub repository

Copy these two folders into your existing repository, then:

```bash
git add task-2-social-media task-4-realtime-communication
git commit -m "Add social media and real-time communication tasks"
git push
```

## Run Task 2

```bash
cd task-2-social-media
npm install
npm start
```

Open http://localhost:3002

## Run Task 4

In another terminal:

```bash
cd task-4-realtime-communication
npm install
npm start
```

Open http://localhost:3004 in two browser windows and use the same room ID.
