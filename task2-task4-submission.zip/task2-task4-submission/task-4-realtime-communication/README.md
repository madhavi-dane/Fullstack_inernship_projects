# Task 4 – Real-Time Communication App

A WebRTC + Socket.IO collaboration demo.

## Features
- Multi-user audio/video
- Screen sharing
- Socket.IO signaling and chat
- Collaborative whiteboard
- Small peer-to-peer file transfer

## Run
```bash
npm install
npm start
```

Open `http://localhost:3004` in two browser windows and join the same room.

## Important
Camera/microphone access works best on `localhost` during development. Production deployment should use HTTPS. A production app should also add authentication, room authorization, TURN servers, stronger file-transfer validation/storage, rate limiting and logging.

## Internship demo
Show two browser windows joining the same room, video/audio, screen sharing, chat, whiteboard and file sharing.
