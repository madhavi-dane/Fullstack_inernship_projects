const express=require("express"),http=require("http"),{Server}=require("socket.io"),path=require("path");
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.static(path.join(__dirname,"public")));
io.on("connection",socket=>{
 socket.on("join-room",room=>{
   room=String(room||"").trim().slice(0,80);if(!room)return;
   socket.join(room);socket.data.room=room;
   const peers=[...(io.sockets.adapter.rooms.get(room)||[])].filter(id=>id!==socket.id);
   socket.emit("existing-peers",peers);socket.to(room).emit("peer-joined",socket.id);
   socket.on("signal",d=>{if(d?.to)io.to(d.to).emit("signal",{from:socket.id,signal:d.signal})});
   socket.on("chat",msg=>io.to(room).emit("chat",{from:socket.id,msg:String(msg).slice(0,1000)}));
   socket.on("draw",data=>socket.to(room).emit("draw",data));
   socket.on("file-meta",data=>socket.to(room).emit("file-meta",data));
   socket.on("file-chunk",data=>socket.to(room).emit("file-chunk",data));
   socket.on("leave-room",()=>{socket.leave(room);socket.to(room).emit("peer-left",socket.id)});
 });
 socket.on("disconnect",()=>{if(socket.data.room)socket.to(socket.data.room).emit("peer-left",socket.id)});
});
server.listen(3004,()=>console.log("Task 4 running at http://localhost:3004"));
