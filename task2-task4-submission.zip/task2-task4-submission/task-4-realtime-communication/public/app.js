const socket=io(),peers=new Map(),ice={iceServers:[{urls:"stun:stun.l.google.com:19302"}]};
let room="",localStream=null,screenTrack=null,fileMeta=null,fileChunks=[];
const $=id=>document.getElementById(id);
async function join(){
 room=$("room").value.trim();if(!room)return alert("Enter a room ID");
 try{localStream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});$("local").srcObject=localStream;socket.emit("join-room",room)}
 catch(e){alert("Camera/microphone permission is required for video calling.")}
}
function createPeer(id,initiator){
 let pc=new RTCPeerConnection(ice);localStream.getTracks().forEach(t=>pc.addTrack(t,localStream));
 let v=document.createElement("video");v.id="peer-"+id;v.autoplay=true;v.playsInline=true;$("videos").appendChild(v);
 pc.ontrack=e=>v.srcObject=e.streams[0];
 pc.onicecandidate=e=>e.candidate&&socket.emit("signal",{to:id,signal:{candidate:e.candidate}});
 peers.set(id,pc);
 if(initiator)pc.createOffer().then(o=>pc.setLocalDescription(o)).then(()=>socket.emit("signal",{to:id,signal:{description:pc.localDescription}}));
 return pc;
}
socket.on("existing-peers",ids=>ids.forEach(id=>createPeer(id,true)));
socket.on("peer-joined",id=>createPeer(id,false));
socket.on("signal",async({from,signal})=>{
 let pc=peers.get(from)||createPeer(from,false);
 if(signal.description){await pc.setRemoteDescription(signal.description);if(signal.description.type==="offer"){const a=await pc.createAnswer();await pc.setLocalDescription(a);socket.emit("signal",{to:from,signal:{description:pc.localDescription}})}}
 else if(signal.candidate)try{await pc.addIceCandidate(signal.candidate)}catch(e){}
});
socket.on("peer-left",id=>{peers.get(id)?.close();peers.delete(id);$("peer-"+id)?.remove()});
async function shareScreen(){
 if(!localStream)return alert("Join a room first");
 try{const s=await navigator.mediaDevices.getDisplayMedia({video:true});screenTrack=s.getVideoTracks()[0];for(const pc of peers.values()){const sender=pc.getSenders().find(x=>x.track?.kind==="video");if(sender)sender.replaceTrack(screenTrack)}screenTrack.onended=stopScreen}catch(e){}
}
function stopScreen(){const cam=localStream.getVideoTracks()[0];for(const pc of peers.values()){const sender=pc.getSenders().find(x=>x.track?.kind==="video");if(sender)sender.replaceTrack(cam)}screenTrack=null}
function sendChat(){const m=$("msg").value.trim();if(m){socket.emit("chat",m);$("msg").value=""}}
socket.on("chat",x=>{const d=document.createElement("div");d.textContent=x.from+": "+x.msg;$("messages").appendChild(d)});
const c=$("board"),ctx=c.getContext("2d");let drawing=false,last=null;
c.onpointerdown=e=>{drawing=true;last=[e.offsetX,e.offsetY]};c.onpointerup=()=>drawing=false;c.onpointerleave=()=>drawing=false;
c.onpointermove=e=>{if(!drawing)return;const now=[e.offsetX,e.offsetY];line(last,now);socket.emit("draw",{a:last,b:now});last=now};
function line(a,b){ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}
socket.on("draw",d=>line(d.a,d.b));function clearBoard(){ctx.clearRect(0,0,c.width,c.height)}
async function sendFile(){
 const f=$("file").files[0];if(!f)return;if(f.size>5*1024*1024)return alert("Demo limit: 5 MB");
 const buf=await f.arrayBuffer();socket.emit("file-meta",{name:f.name,type:f.type,size:f.size});
 for(let i=0;i<buf.byteLength;i+=16000)socket.emit("file-chunk",Array.from(new Uint8Array(buf.slice(i,i+16000))));
}
socket.on("file-meta",m=>{fileMeta=m;fileChunks=[]});
socket.on("file-chunk",chunk=>{fileChunks.push(new Uint8Array(chunk));const total=fileChunks.reduce((n,x)=>n+x.length,0);if(fileMeta&&total>=fileMeta.size){const blob=new Blob(fileChunks,{type:fileMeta.type}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=fileMeta.name;a.textContent="Download "+fileMeta.name;document.body.appendChild(a);document.body.appendChild(document.createElement("br"));fileChunks=[]}});
